<script>
import { h } from 'vue';

export default {
    name: 'i-remix-bookmark',
    props: ['width', 'height', 'color', 'crop', 'version'],
    render() {
        let w = this.width, s = this.height || (!this.width ? '1em' : null),f=this.color || 'currentColor',v = this.version,c = this.crop !== undefined;
        if (v === 'line')
    return h('svg',{"viewBox":c ? '4 2 16 20.64' : '0 0 24 24',"width":w,"height":s,"fill":f},[h('path',{d:"M5 2h14a1 1 0 0 1 1 1v19.143a.5.5 0 0 1-.766.424L12 18.03l-7.234 4.536A.5.5 0 0 1 4 22.143V3a1 1 0 0 1 1-1zm13 2H6v15.432l6-3.761 6 3.761V4z"},[])]);
return h('svg',{"viewBox":c ? '4 2 16 20.64' : '0 0 24 24',"width":w,"height":s,"fill":f},[h('path',{d:"M5 2h14a1 1 0 0 1 1 1v19.143a.5.5 0 0 1-.766.424L12 18.03l-7.234 4.536A.5.5 0 0 1 4 22.143V3a1 1 0 0 1 1-1z"},[])]);
    }
}
</script>
# Remix Icon

Icons from Remix icon:

https://remixicon.com/
https://github.com/Remix-Design/RemixIcon

import { defineConfig } from "vite";
import { getBaseConfig } from '../../vite.config';

export default defineConfig(getBaseConfig('utils-object'));

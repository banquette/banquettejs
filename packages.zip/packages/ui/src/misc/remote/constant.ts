
export const RemoteModuleEvents = {
    ConfigurationChange: Symbol('configuration-changed')
}

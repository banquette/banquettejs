
export interface CheckboxGroupInterface {
    name: string|symbol;
    controlId: number;
}

import { Parser } from "acorn";
import { getParentsOf, isNode, searchNodes } from "./acorn-utils.js";

const PureFunctions = ['__decorate', '__decorateClass'];

/**
 * Add a "/* @__PURE__ *\/" comment before any declaration of __decorate utility to allow for tree shaking.
 */
export default function PureDecorators() {
    return {
        name: 'pure-decorators',
        apply: 'build',

        async transform(code, id) {
            try {
                if (!id.match(/\.ts$|(\?|&)lang\.ts/)) {
                    return null;
                }
                const rootNode = Parser.parse(code, {ecmaVersion: 'latest', sourceType: 'module'});
                let selectedNodes = searchNodes(rootNode, 'CallExpression').filter((node) => {
                    return PureFunctions.indexOf(node.callee.name) > -1;
                }).sort((a, b) => b.start - a.start);

                const modules = {};
                const extractedDeclarations = [];
                for (let selectedNode of selectedNodes) {
                    const moduleNames = [];
                    const parents = getParentsOf(selectedNode, rootNode);

                    if (selectedNode.arguments?.length > 1 && selectedNode.arguments[1].object?.type === 'Identifier') {
                        moduleNames.push(selectedNode.arguments[1].object.name);
                    }
                    if (parents.length > 1) {
                        selectedNode = parents[1];
                    }
                    extractedDeclarations.push(code.substring(selectedNode.start, selectedNode.end));
                    code = code.substring(0, selectedNode.start) + code.substring(selectedNode.end);

                    for (let i = parents.length - 1; i > 0; --i) {
                        const parent = parents[i];
                        if (isNode(parent, 'AssignmentExpression') && moduleNames.indexOf(parent.left.name) < 0) {
                            moduleNames.push(parent.left.name);
                        }
                    }
                    if (moduleNames.length > 0) {
                        const moduleName = moduleNames[0];
                        const placeholder = `__##${moduleName}##__`;
                        if (typeof (modules[moduleName]) === 'undefined') {
                            modules[moduleName] = {aliases: moduleNames, placeholder};
                            code = code.substring(0, selectedNode.start) + placeholder + code.substring(selectedNode.start);
                        }
                    }
                }
                const indexedByModule = extractedDeclarations.reduce((index, item) => {
                    for (const module of Object.keys(modules)) {
                        for (const alias of modules[module].aliases) {
                            if (item.includes(alias)) {
                                if (typeof (index[module]) === 'undefined') {
                                    index[module] = [];
                                }
                                index[module].push(item);
                                return index;
                            }
                        }
                    }
                    throw `Module not found in declaration "${item}".`;
                }, {});

                for (const moduleName of Object.keys(indexedByModule)) {
                    let inner = indexedByModule[moduleName].reverse().join("\n");
                    for (const alias of modules[moduleName].aliases) {
                        inner = inner.replaceAll(new RegExp(alias, 'g'), '_');
                    }
                    code = code.replace(modules[moduleName].placeholder, `
${moduleName} = /**!PURE*/ ((_) => {
    ${inner};
    return _;
})(${moduleName});
`);
                }
                for (const module of Object.keys(modules)) {
                    code = code.replace(modules[module].placeholder, '');
                }
                return code;
            } catch (e) {
                console.log(e);
            }
        },

        generateBundle(options, bundle) {
            for (const fileName of Object.keys(bundle)) {
                const chunk = bundle[fileName];
                if (typeof(chunk) === 'object' && typeof(chunk.code) === 'string') {
                    chunk.code = chunk.code.replaceAll(/\/\*\*\!PURE\*\/\s*/g, '/* @__PURE__ */ ');
                }
            }
        },
    };
}

// import { Parser } from "acorn";
// import {getParentsOf, searchNodes} from "./acorn-utils.js";
//
// const PureFunctions = ['__decorateClass'];
//
// /**
//  * Add a "/* @__PURE__ *\/" comment before any declaration of __decorate utility to allow for tree shaking.
//  */
// export default function PureDecorators() {
//     return {
//         name: 'pure-decorators',
//         apply: 'build',
//
//         async transform(code, id) {
//             if (!id.match(/\.ts$|(\?|&)lang\.ts/) || true) {
//                 return null;
//             }
//             const rootNode = Parser.parse(code, {ecmaVersion: 'latest', sourceType: 'module'});
//             let selectedNodes = searchNodes(rootNode, 'CallExpression').filter((node) => {
//                 return PureFunctions.indexOf(node.callee.name) > -1;
//             });
//             for (let i = 0, c = selectedNodes.length; i < c; ++i) {
//                 if (selectedNodes[i].callee.name === '__decorateClass') {
//                     for (const argument of selectedNodes[i].arguments) {
//                         if (argument.type === 'MemberExpression' && argument.property && argument.property.name === 'prototype') {
//                             selectedNodes.push(argument);
//                         }
//                     }
//                 }
//             }
//             selectedNodes = selectedNodes.sort((a, b) => b.start - a.start);
//             for (const selectedNode of selectedNodes) {
//                 if (selectedNode.type === 'MemberExpression' && selectedNode.property && selectedNode.property.name === 'prototype') {
//                     const argumentValue = code.substring(selectedNode.start, selectedNode.end);
//                     const match = argumentValue.match(/^([a-z0-9_]+)\.prototype/i, argumentValue);
//                     if (match) {
//                         code = code.substring(0, selectedNode.start) + `((_) => _.prototype)(${match[1]})` + code.substring(selectedNode.end);
//                     }
//                     continue ;
//                 }
//                 const parents = getParentsOf(selectedNode, rootNode);
//                 if (parents.length === 2) {
//                     code = code.substring(0, selectedNode.start) + ";console.warn('/**!PURE*/'); " + code.substring(selectedNode.start);
//                     continue ;
//                 }
//                 code = code.substring(0, selectedNode.start) + "/**!PURE*/\n" + code.substring(selectedNode.start);
//             }
//             return code;
//         },
//
//         generateBundle(options, bundle) {
//             for (const fileName of Object.keys(bundle)) {
//                 const chunk = bundle[fileName];
//                 if (typeof(chunk) === 'object' && typeof(chunk.code) === 'string') {
//                     chunk.code = chunk.code.replaceAll(/console\.warn\(('|")\/\*\*\!PURE\*\/('|")\);?\s*/g, '/* @__PURE__ */ ');
//                     chunk.code = chunk.code.replaceAll(/\/\*\*\!PURE\*\/\s*/g, '/* @__PURE__ */ ');
//                 }
//             }
//         },
//     };
// }

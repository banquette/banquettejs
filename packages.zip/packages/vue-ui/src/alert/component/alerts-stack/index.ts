export { default as BtAlertsStack } from './alerts-stack.component.vue';

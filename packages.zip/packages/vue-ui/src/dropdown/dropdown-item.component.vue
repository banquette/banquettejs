<template>
    <div class="bt-dropdown-item">
        <slot></slot>
    </div>
</template>
<script lang="ts">
import { Component } from "@banquette/vue-typescript";

@Component('bt-dropdown-item')
export default class BtDropdownItem {

}
</script>

<template>
    <hr class="bt-dropdown-divider" />
</template>
<script lang="ts">
import { Component } from "@banquette/vue-typescript";

@Component('bt-dropdown-divider')
export default class BtDropdownDivider {

}
</script>

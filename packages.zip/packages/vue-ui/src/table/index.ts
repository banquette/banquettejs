export { default as BtTable } from './table.component.vue';

<style src="./test1.component.css" scoped></style>
<template src="./test1.component.html"></template>
<script lang="ts">
import { Component, Prop } from "@banquette/vue-typescript";

@Component()
export default class Test {
    @Prop({type: String}) public id!: string;

    public test(): void {
        console.warn('test BtTest1');
    }
}
</script>

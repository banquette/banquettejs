export { default as BtTest1 } from './test1.component.vue';

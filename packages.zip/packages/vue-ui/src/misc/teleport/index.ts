
export { default as BtTeleport } from './teleport.component.vue';

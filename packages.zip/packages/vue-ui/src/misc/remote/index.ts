
export { default as BtRemote } from './remote.component.vue';

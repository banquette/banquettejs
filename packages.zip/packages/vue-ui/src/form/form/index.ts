
export { default as BtForm } from './form.component.vue';
export * from './form-view-data.interface';

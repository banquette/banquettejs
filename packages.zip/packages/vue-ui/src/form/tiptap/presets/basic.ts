import { registerTiptapConfiguration } from "../utils";
import '../modules/bold';

/**
 * Editor only containing basic modules.
 * TODO
 */
// registerTiptapConfiguration('basic', {
//     toolbars: [['bold']]
// });

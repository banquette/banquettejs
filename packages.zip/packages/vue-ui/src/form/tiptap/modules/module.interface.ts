export interface ModuleInterface {

}

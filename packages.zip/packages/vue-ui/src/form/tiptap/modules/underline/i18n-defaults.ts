import { I18nInterface } from "./i18n.interface";

export const I18nDefaults: I18nInterface = {
    popover: 'Underline (Ctrl + U)'
};

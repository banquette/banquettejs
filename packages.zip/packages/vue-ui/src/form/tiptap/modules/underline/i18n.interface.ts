
export interface I18nInterface {
    /**
     * Text of the popover.
     * An empty string will disable the popover.
     */
    popover: string;
}

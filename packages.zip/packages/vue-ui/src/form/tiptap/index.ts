export { default as BtFormTiptap } from './tiptap.component.vue';

export * from './modules/module.interface';
export * from './modules/underline';
export * from './tiptap-configuration.service';
export * from './tiptap-configuration.interface';
export * from './type';
export * from './utils';
// export * from './presets';

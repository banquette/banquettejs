// Used as origin for all choices created by the component.
export const PropOrigin = 'prop';
export const BeforeSlotOrigin = 'slot-before';
export const AfterSlotOrigin = 'slot-after';

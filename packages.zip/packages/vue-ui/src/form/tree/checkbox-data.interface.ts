import { FormControl } from "@banquette/form";

export interface CheckboxDataInterface {
    control: FormControl;
    indeterminate: boolean;
}

export { default as BtFormFile } from './file.component.vue';

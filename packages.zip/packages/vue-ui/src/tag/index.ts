
export { default as BtTag } from './tag.component.vue';

export { default as BtTabs } from './tabs.component.vue';

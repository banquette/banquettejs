export { default as BtTab } from './tab.component.vue';

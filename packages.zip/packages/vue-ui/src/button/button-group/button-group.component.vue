<style src="./button-group.component.css" scoped></style>
<template src="./button-group.component.html" ></template>
<script lang="ts">
import { Component } from "@banquette/vue-typescript";

@Component('bt-button-group')
export default class BtButtonGroup {

}
</script>

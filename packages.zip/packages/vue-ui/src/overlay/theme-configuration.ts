
export const ThemeConfiguration = {
    css: {
        vars: {
            backgroundColor: 'overlay-background-color',
            zIndex: 'overlay-z-index'
        },
        selectors: {

        }
    }
};

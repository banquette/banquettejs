
export const ThemeConfiguration = {
    css: {
        selectors: {
            root: '&.bt-icon'
        }
    }
};

export { default as BtIcon } from './icon.component.vue';
export * from './icon.interface';

/**
 * The CSS defines the base variables.
 */
/**
 * Theme adjustments are all defined in Typescript.
 */
import './components';
import './styles/vars.css';

<style src="./test2.component.css" scoped></style>
<template src="./test2.component.html"></template>
<script lang="ts">
import { Component, Prop } from '@banquette/vue-typescript';

@Component('bt-test2')
export default class BtTest2 {
   @Prop({type: String, default: 'BtTest2'}) public propTest!: string;

    public test(): void {
        console.warn('test BtTest2');
    }
}
</script>

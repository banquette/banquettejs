export { default as BtTest2 } from './test2.component.vue';

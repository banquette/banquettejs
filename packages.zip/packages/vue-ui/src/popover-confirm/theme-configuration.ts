
export const ThemeConfiguration = {
    css: {
        vars: {

        },
        selectors: {

        }
    }
};

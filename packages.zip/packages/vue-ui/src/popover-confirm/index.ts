export { default as BtPopoverConfirm } from './popover-confirm.component.vue';

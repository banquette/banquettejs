export { default as BtProgressHorizontal } from './progress-horizontal.component.vue';
